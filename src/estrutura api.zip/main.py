"""API FastAPI para inferência de churn em tempo real.

Rotas:
    GET  /health   → status do serviço e dos artefatos carregados
    POST /predict  → probabilidade e predição de churn para um cliente

Ciclo de vida:
    1. Startup (lifespan): carrega preprocessor.pkl e best_mlp_etapa2.pt
       uma única vez → armazenados em app.state
    2. Por requisição: Pydantic valida → preprocessor transforma →
       modelo prediz → resposta JSON
    3. Shutdown: cleanup (noop no caso atual)
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, status

from api.dependencies import get_model, get_preprocessor
from api.middleware import LatencyLoggingMiddleware
from churn_telecom.config import PROJECT_ROOT, get_logger
from churn_telecom.model_loader import ChurnModelLoader
from churn_telecom.preprocessing import ChurnPreprocessor
from churn_telecom.schemas import CustomerFeatures, HealthResponse, PredictResponse

logger = get_logger("api.main")

# ── Configurações carregadas de variáveis de ambiente ──────────────────────────
MODEL_PATH = Path(os.getenv("MODEL_PATH", str(PROJECT_ROOT / "models" / "best_mlp_etapa2.pt")))
PREPROCESSOR_PATH = Path(
    os.getenv("PREPROCESSOR_PATH", str(PROJECT_ROOT / "models" / "preprocessor.pkl"))
)
HIDDEN_DIMS: list[int] = [
    int(x) for x in os.getenv("HIDDEN_DIMS", "64,32").split(",")
]
DROPOUT: float = float(os.getenv("DROPOUT", "0.35"))
THRESHOLD: float = float(os.getenv("PREDICT_THRESHOLD", "0.50"))
MODEL_VERSION: str = os.getenv("MODEL_VERSION", "etapa2-v1")


# ── Lifespan — carrega artefatos uma única vez no startup ──────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Carrega preprocessor e modelo no startup; libera no shutdown."""
    logger.info("Startup | carregando artefatos...")

    try:
        app.state.preprocessor = ChurnPreprocessor(path=PREPROCESSOR_PATH)
    except FileNotFoundError as exc:
        logger.error("Preprocessor não encontrado: %s", exc)
        app.state.preprocessor = None

    try:
        input_dim = (
            app.state.preprocessor.n_features_out
            if app.state.preprocessor
            else 30
        )
        app.state.model = ChurnModelLoader(
            model_path=MODEL_PATH,
            input_dim=input_dim,
            hidden_dims=HIDDEN_DIMS,
            dropout=DROPOUT,
            version=MODEL_VERSION,
        )
    except FileNotFoundError as exc:
        logger.error("Modelo não encontrado: %s", exc)
        app.state.model = None

    logger.info(
        "Startup concluído | preprocessor=%s | model=%s",
        "OK" if app.state.preprocessor else "FALHOU",
        "OK" if app.state.model else "FALHOU",
    )

    yield  # ← API fica disponível aqui

    logger.info("Shutdown | liberando recursos...")


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Churn Prediction API",
    description=(
        "API de inferência para previsão de churn em telecomunicações. "
        "Modelo: ChurnMLPv2 treinado com PyTorch. "
        "Critério: minimizar custo total (FN × US$2.903 + FP × US$50)."
    ),
    version=MODEL_VERSION,
    lifespan=lifespan,
)

app.add_middleware(LatencyLoggingMiddleware)


# ── Rotas ──────────────────────────────────────────────────────────────────────
@app.get("/health", response_model=HealthResponse, tags=["infra"])
def health(request: Request) -> HealthResponse:
    """Verifica se o serviço e os artefatos estão operacionais.

    Retorna 200 com status 'healthy' se preprocessor e modelo estão carregados.
    Retorna 200 com status 'degraded' se algum artefato falhou no startup.
    """
    preprocessor_ok = request.app.state.preprocessor is not None
    model_ok = request.app.state.model is not None

    if preprocessor_ok and model_ok:
        s = "healthy"
    elif preprocessor_ok or model_ok:
        s = "degraded"
    else:
        s = "unhealthy"

    return HealthResponse(
        status=s,
        model_loaded=model_ok,
        preprocessor_loaded=preprocessor_ok,
        model_version=MODEL_VERSION,
    )


@app.post("/predict", response_model=PredictResponse, tags=["inference"])
def predict(
    customer: CustomerFeatures,
    request: Request,
    preprocessor: ChurnPreprocessor = Depends(get_preprocessor),
    model: ChurnModelLoader = Depends(get_model),
) -> PredictResponse:
    """Prediz a probabilidade de churn para um cliente.

    Fluxo interno:
        1. Pydantic já validou o payload antes de chegar aqui
        2. preprocessor.transform() aplica o ColumnTransformer fitado no treino
        3. model.predict_proba() executa o forward pass do ChurnMLPv2
        4. Compara com threshold para gerar predição binária

    Args:
        customer: features do cliente validadas pelo Pydantic
        request:  request FastAPI (para extrair request_id do middleware)
        preprocessor: injetado via Depends(get_preprocessor)
        model: injetado via Depends(get_model)

    Returns:
        PredictResponse com probabilidade, predição, threshold e metadados

    Raises:
        HTTPException 422: payload inválido (tratado automaticamente pelo Pydantic)
        HTTPException 500: erro inesperado no processamento
    """
    request_id: str = getattr(request.state, "request_id", "unknown")

    try:
        X = preprocessor.transform(customer.model_dump())
    except ValueError as exc:
        logger.warning("Erro no preprocessamento | id=%s | %s", request_id, exc)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Erro no preprocessamento: {exc}",
        ) from exc

    try:
        proba = model.predict_proba(X)
    except Exception as exc:
        logger.error("Erro na inferência | id=%s | %s", request_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno na inferência do modelo.",
        ) from exc

    churn = bool(proba >= THRESHOLD)

    logger.info(
        "PREDICT | id=%s | proba=%.4f | churn=%s | threshold=%.2f",
        request_id,
        proba,
        churn,
        THRESHOLD,
    )

    return PredictResponse(
        churn_probability=round(proba, 6),
        churn_prediction=churn,
        threshold=THRESHOLD,
        model_version=MODEL_VERSION,
        request_id=request_id,
    )

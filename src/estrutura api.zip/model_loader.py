"""Carregamento e inferência do modelo PyTorch em produção.

Responsabilidade única: carregar o ChurnMLPv2 a partir do .pt
e expor predict_proba(X) → float.

Separado do preprocessing para respeitar SRP:
  - preprocessing.py: raw dict → numpy array
  - model_loader.py:  numpy array → probabilidade
  - main.py:          orquestra ambos
"""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import torch

from churn_telecom.models.mlp import build_mlp

logger = logging.getLogger(__name__)


class ChurnModelLoader:
    """Carrega o checkpoint .pt e executa inferência.

    O modelo é carregado uma única vez no startup da API.
    A arquitetura (hidden_dims, dropout) deve corresponder
    exatamente ao que foi salvo no .pt — use os metadados
    do MLflow run para garantir consistência.

    Args:
        model_path: caminho para o arquivo .pt (state_dict)
        input_dim:  número de features (saída do preprocessor)
        hidden_dims: lista de dimensões das camadas ocultas
        dropout:    taxa de dropout usada no treino
        device:     "cpu" ou "cuda"
        version:    string de versão para rastreabilidade nos logs
    """

    def __init__(
        self,
        model_path: Path,
        input_dim: int,
        hidden_dims: list[int],
        dropout: float = 0.35,
        device: str = "cpu",
        version: str = "1.0.0",
    ) -> None:
        if not model_path.exists():
            raise FileNotFoundError(
                f"Modelo não encontrado em '{model_path}'. "
                "Execute o notebook 03 para gerar o arquivo."
            )

        self.version = version
        self._device = torch.device(device)

        # Reconstrói a arquitetura e carrega os pesos
        self._model = build_mlp(input_dim, hidden_dims, dropout, device)
        state = torch.load(model_path, map_location=self._device)
        self._model.load_state_dict(state)
        self._model.eval()

        n_params = sum(p.numel() for p in self._model.parameters())
        logger.info(
            "ChurnModelLoader | path=%s | version=%s | device=%s | params=%d",
            model_path,
            version,
            device,
            n_params,
        )

    def predict_proba(self, X: np.ndarray) -> float:
        """Retorna a probabilidade de churn para uma amostra.

        Args:
            X: array de shape (1, input_dim) com dtype float32

        Returns:
            Probabilidade de churn em [0.0, 1.0]
        """
        tensor = torch.tensor(X, dtype=torch.float32).to(self._device)
        with torch.no_grad():
            logit = self._model(tensor).squeeze()
        return float(torch.sigmoid(logit).item())

    def predict_batch(self, X: np.ndarray) -> np.ndarray:
        """Retorna probabilidades para um batch de amostras.

        Args:
            X: array de shape (n, input_dim) com dtype float32

        Returns:
            np.ndarray de shape (n,) com probabilidades em [0, 1]
        """
        tensor = torch.tensor(X, dtype=torch.float32).to(self._device)
        with torch.no_grad():
            logits = self._model(tensor).squeeze(1)
        return torch.sigmoid(logits).cpu().numpy()

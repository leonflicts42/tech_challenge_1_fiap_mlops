"""Injeção de dependência para a API FastAPI.

Expõe get_preprocessor() e get_model() como dependências injetáveis.
Os objetos são singletons inicializados no lifespan do app (main.py)
e armazenados no app.state — zero I/O por requisição.
"""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status

from churn_telecom.model_loader import ChurnModelLoader
from churn_telecom.preprocessing import ChurnPreprocessor


def get_preprocessor(request: Request) -> ChurnPreprocessor:
    """Retorna o ChurnPreprocessor inicializado no lifespan.

    Raises:
        HTTPException 503: se o preprocessor não estiver carregado.
    """
    preprocessor: ChurnPreprocessor | None = getattr(
        request.app.state, "preprocessor", None
    )
    if preprocessor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Preprocessor não inicializado. Serviço indisponível.",
        )
    return preprocessor


def get_model(request: Request) -> ChurnModelLoader:
    """Retorna o ChurnModelLoader inicializado no lifespan.

    Raises:
        HTTPException 503: se o modelo não estiver carregado.
    """
    model: ChurnModelLoader | None = getattr(request.app.state, "model", None)
    if model is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Modelo não inicializado. Serviço indisponível.",
        )
    return model

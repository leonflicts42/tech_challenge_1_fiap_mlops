"""Testes de contrato da API — rota /predict.

Verificam o comportamento completo da rota:
- Response schema (campos obrigatórios, tipos)
- Lógica de threshold (proba alta → churn True)
- Rastreabilidade (request_id único por requisição)
- Casos de borda (payload mínimo, campos extremos)
"""
from __future__ import annotations

import uuid

from fastapi.testclient import TestClient


class TestPredictResponseSchema:
    """Verifica o schema da resposta de /predict."""

    def test_response_has_required_fields(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        data = test_client.post("/predict", json=valid_payload).json()
        for field in ["churn_probability", "churn_prediction", "threshold", "model_version", "request_id"]:
            assert field in data, f"Campo '{field}' ausente na resposta"

    def test_probability_between_0_and_1(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        data = test_client.post("/predict", json=valid_payload).json()
        assert 0.0 <= data["churn_probability"] <= 1.0

    def test_prediction_is_boolean(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        data = test_client.post("/predict", json=valid_payload).json()
        assert isinstance(data["churn_prediction"], bool)

    def test_request_id_is_valid_uuid(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        data = test_client.post("/predict", json=valid_payload).json()
        uuid.UUID(data["request_id"])  # lança ValueError se inválido

    def test_model_version_non_empty(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        data = test_client.post("/predict", json=valid_payload).json()
        assert len(data["model_version"]) > 0


class TestPredictLogic:
    """Verifica a lógica de threshold e predição."""

    def test_high_proba_predicts_churn(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        """Mock retorna 0.75 → com threshold=0.50, deve ser churn=True."""
        data = test_client.post("/predict", json=valid_payload).json()
        threshold = data["threshold"]
        proba = data["churn_probability"]
        assert data["churn_prediction"] == (proba >= threshold)

    def test_threshold_matches_config(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        """Threshold retornado deve ser o configurado no app."""
        from api.main import THRESHOLD
        data = test_client.post("/predict", json=valid_payload).json()
        assert abs(data["threshold"] - THRESHOLD) < 1e-6


class TestPredictTraceability:
    """Verifica rastreabilidade — request_id único por requisição."""

    def test_request_ids_are_unique(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        ids = {
            test_client.post("/predict", json=valid_payload).json()["request_id"]
            for _ in range(5)
        }
        assert len(ids) == 5, "Request IDs duplicados detectados"

    def test_request_id_in_header_matches_body(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        response = test_client.post("/predict", json=valid_payload)
        body_id = response.json()["request_id"]
        header_id = response.headers.get("x-request-id")
        assert body_id == header_id


class TestPredictEdgeCases:
    """Casos de borda — valores extremos mas válidos."""

    def test_zero_tenure_accepted(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        payload = {
            **valid_payload,
            "tenure_months": 0,
            "total_charges": 0.0,
            "charges_per_month": 0.0,
        }
        response = test_client.post("/predict", json=payload)
        assert response.status_code == 200

    def test_two_year_contract_accepted(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        payload = {**valid_payload, "contract": "Two year", "is_month_to_month": 0}
        response = test_client.post("/predict", json=payload)
        assert response.status_code == 200

    def test_empty_body_returns_422(self, test_client: TestClient) -> None:
        response = test_client.post("/predict", json={})
        assert response.status_code == 422

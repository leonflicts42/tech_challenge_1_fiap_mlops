"""Preprocessamento para inferência em produção.

Responsabilidade única: converter o dict validado pelo Pydantic
em numpy array float32 pronto para o modelo PyTorch.

O preprocessor.pkl é o mesmo ColumnTransformer fitado no treino
(notebook 1_03). Reutilizá-lo garante que a inferência aplica
exatamente as mesmas transformações que o modelo viu:
  - log1p + StandardScaler nas features numéricas
  - OrdinalEncoder nas binárias Yes/No
  - OneHotEncoder nas nominais com 3+ categorias
  - passthrough nas features de engenharia já binárias
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# Ordem das colunas exata do ColumnTransformer fitado no treino
_FEATURE_ORDER = [
    "tenure_months",
    "monthly_charges",
    "total_charges",
    "num_services",
    "charges_per_month",
    "partner",
    "dependents",
    "phone_service",
    "multiple_lines",
    "online_security",
    "online_backup",
    "device_protection",
    "tech_support",
    "streaming_tv",
    "streaming_movies",
    "paperless_billing",
    "senior_citizen",
    "internet_service",
    "contract",
    "payment_method",
    "gender",
    "tenure_group",
    "is_month_to_month",
    "has_security_support",
    "is_fiber_optic",
]


class ChurnPreprocessor:
    """Encapsula o ColumnTransformer fitado no treino.

    O .pkl é carregado uma única vez no __init__ (startup da API)
    e reutilizado em todas as requisições — sem I/O por chamada.

    Args:
        path: caminho para o preprocessor.pkl serializado pelo notebook 1_03
    """

    def __init__(self, path: Path) -> None:
        if not path.exists():
            raise FileNotFoundError(
                f"Preprocessor não encontrado em '{path}'. "
                "Execute o notebook 1_03 para gerar o arquivo."
            )
        self._preprocessor = joblib.load(path)
        self._n_features_out: int = len(
            self._preprocessor.get_feature_names_out()
        )
        logger.info(
            "ChurnPreprocessor carregado | path=%s | n_features_out=%d",
            path,
            self._n_features_out,
        )

    def transform(self, data: dict[str, Any]) -> np.ndarray:
        """Transforma um dicionário de features em array float32.

        Args:
            data: dict com as features do cliente, conforme CustomerFeatures.
                  Deve conter exatamente as colunas usadas no treinamento.

        Returns:
            np.ndarray de shape (1, n_features) com dtype float32.

        Raises:
            ValueError: se o dicionário contiver colunas inesperadas
                        ou faltar colunas obrigatórias.
        """
        df = pd.DataFrame([data])

        # Garante a ordem correta das colunas antes de passar ao transformer
        missing = [c for c in _FEATURE_ORDER if c not in df.columns]
        if missing:
            raise ValueError(f"Features ausentes no payload: {missing}")

        df = df[_FEATURE_ORDER]
        X = self._preprocessor.transform(df)
        return X.astype(np.float32)

    @property
    def n_features_out(self) -> int:
        """Número de features após transformação (input_dim para o modelo)."""
        return self._n_features_out

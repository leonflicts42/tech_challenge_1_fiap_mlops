"""Middleware de logging estruturado e rastreabilidade.

Adiciona a cada requisição:
- X-Request-ID: UUID único para correlação de logs
- Log de entrada (método, path, request_id)
- Log de saída (status_code, latência em ms, request_id)
"""
from __future__ import annotations

import logging
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class LatencyLoggingMiddleware(BaseHTTPMiddleware):
    """Loga latência e injeta X-Request-ID em todas as respostas.

    O request_id é propagado para a resposta via header e está
    disponível em request.state.request_id para as rotas usarem
    na PredictResponse.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        logger.info(
            "REQUEST | id=%s | method=%s | path=%s",
            request_id,
            request.method,
            request.url.path,
        )

        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception as exc:
            latency_ms = (time.perf_counter() - start) * 1000
            logger.error(
                "ERROR | id=%s | path=%s | latency_ms=%.1f | error=%s",
                request_id,
                request.url.path,
                latency_ms,
                str(exc),
            )
            raise

        latency_ms = (time.perf_counter() - start) * 1000
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Latency-Ms"] = f"{latency_ms:.1f}"

        logger.info(
            "RESPONSE | id=%s | status=%d | latency_ms=%.1f",
            request_id,
            response.status_code,
            latency_ms,
        )
        return response

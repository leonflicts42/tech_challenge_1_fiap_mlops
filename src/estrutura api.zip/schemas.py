"""Schemas Pydantic para validação de entrada e saída da API de churn.

Contratos de interface da rota /predict:
- CustomerFeatures: payload de entrada com validação de tipos e valores
- PredictResponse: resposta padronizada com probabilidade e metadados
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class CustomerFeatures(BaseModel):
    """Features de entrada para predição de churn.

    Representa um snapshot do cliente no momento da inferência.
    Todos os campos correspondem às features usadas no treinamento
    após feature engineering do notebook 1_02.
    """

    # ── Demográficas ──────────────────────────────────────────────────────────
    gender: Literal["Male", "Female"]
    senior_citizen: Literal["No", "Yes"]
    partner: Literal["No", "Yes"]
    dependents: Literal["No", "Yes"]

    # ── Contrato e serviços ───────────────────────────────────────────────────
    tenure_months: int = Field(ge=0, le=720)
    phone_service: Literal["No", "Yes"]
    multiple_lines: Literal["No", "Yes"]
    internet_service: Literal["DSL", "Fiber optic", "No"]
    online_security: Literal["No", "Yes"]
    online_backup: Literal["No", "Yes"]
    device_protection: Literal["No", "Yes"]
    tech_support: Literal["No", "Yes"]
    streaming_tv: Literal["No", "Yes"]
    streaming_movies: Literal["No", "Yes"]
    contract: Literal["Month-to-month", "One year", "Two year"]
    paperless_billing: Literal["No", "Yes"]
    payment_method: Literal[
        "Electronic check",
        "Mailed check",
        "Bank transfer (automatic)",
        "Credit card (automatic)",
    ]

    # ── Financeiras ───────────────────────────────────────────────────────────
    monthly_charges: float = Field(ge=0.0, le=200.0)
    total_charges: float = Field(ge=0.0)

    # ── Features de engenharia (criadas no 1_02) ──────────────────────────────
    num_services: int = Field(ge=0, le=10)
    charges_per_month: float = Field(ge=0.0)
    is_month_to_month: int = Field(ge=0, le=1)
    tenure_group: Literal["novo", "medio", "longo"]
    has_security_support: int = Field(ge=0, le=1)
    is_fiber_optic: int = Field(ge=0, le=1)

    @field_validator("total_charges")
    @classmethod
    def total_charges_consistent(cls, v: float, info) -> float:
        """Valida que total_charges é plausível dado tenure e monthly_charges."""
        data = info.data
        tenure = data.get("tenure_months", 0)
        monthly = data.get("monthly_charges", 0.0)
        if tenure > 0 and v < monthly * 0.5:
            raise ValueError(
                f"total_charges={v:.2f} inconsistente com "
                f"tenure={tenure} x monthly={monthly:.2f}"
            )
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "gender": "Female",
                "senior_citizen": "No",
                "partner": "Yes",
                "dependents": "No",
                "tenure_months": 12,
                "phone_service": "Yes",
                "multiple_lines": "No",
                "internet_service": "Fiber optic",
                "online_security": "No",
                "online_backup": "Yes",
                "device_protection": "No",
                "tech_support": "No",
                "streaming_tv": "Yes",
                "streaming_movies": "No",
                "contract": "Month-to-month",
                "paperless_billing": "Yes",
                "payment_method": "Electronic check",
                "monthly_charges": 65.5,
                "total_charges": 786.0,
                "num_services": 4,
                "charges_per_month": 65.5,
                "is_month_to_month": 1,
                "tenure_group": "novo",
                "has_security_support": 0,
                "is_fiber_optic": 1,
            }
        }
    }


class PredictResponse(BaseModel):
    """Resposta da rota /predict."""

    churn_probability: float = Field(ge=0.0, le=1.0)
    churn_prediction: bool
    threshold: float
    model_version: str
    request_id: str


class HealthResponse(BaseModel):
    """Resposta da rota /health."""

    status: Literal["healthy", "degraded", "unhealthy"]
    model_loaded: bool
    preprocessor_loaded: bool
    model_version: str

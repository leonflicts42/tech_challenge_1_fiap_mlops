"""Fixtures compartilhadas entre todos os módulos de teste.

Hierarquia de fixtures:
    valid_payload  → dict com features válidas de um cliente
    mock_preprocessor → stub que retorna array float32 sem depender do .pkl
    mock_model     → stub que retorna probabilidade fixa sem depender do .pt
    test_client    → TestClient com mocks injetados no app.state
"""
from __future__ import annotations

import numpy as np
import pytest
from fastapi.testclient import TestClient

from api.main import MODEL_VERSION, THRESHOLD, app


@pytest.fixture(scope="session")
def valid_payload() -> dict:
    """Payload válido de um cliente típico com risco moderado de churn."""
    return {
        "gender": "Female",
        "senior_citizen": "No",
        "partner": "Yes",
        "dependents": "No",
        "tenure_months": 12,
        "phone_service": "Yes",
        "multiple_lines": "No",
        "internet_service": "Fiber optic",
        "online_security": "No",
        "online_backup": "Yes",
        "device_protection": "No",
        "tech_support": "No",
        "streaming_tv": "Yes",
        "streaming_movies": "No",
        "contract": "Month-to-month",
        "paperless_billing": "Yes",
        "payment_method": "Electronic check",
        "monthly_charges": 65.5,
        "total_charges": 786.0,
        "num_services": 4,
        "charges_per_month": 65.5,
        "is_month_to_month": 1,
        "tenure_group": "novo",
        "has_security_support": 0,
        "is_fiber_optic": 1,
    }


class _MockPreprocessor:
    """Stub do ChurnPreprocessor — retorna array float32 sem I/O."""

    n_features_out = 30

    def transform(self, data: dict) -> np.ndarray:
        return np.zeros((1, 30), dtype=np.float32)


class _MockModel:
    """Stub do ChurnModelLoader — retorna probabilidade fixa."""

    version = MODEL_VERSION

    def predict_proba(self, X: np.ndarray) -> float:
        return 0.75


@pytest.fixture(scope="session")
def mock_preprocessor() -> _MockPreprocessor:
    return _MockPreprocessor()


@pytest.fixture(scope="session")
def mock_model() -> _MockModel:
    return _MockModel()


@pytest.fixture(scope="session")
def test_client(mock_preprocessor, mock_model) -> TestClient:
    """TestClient com mocks injetados — não depende dos artefatos em disco."""
    app.state.preprocessor = mock_preprocessor
    app.state.model = mock_model
    return TestClient(app)

"""Schema tests — validam o contrato dos dados com pandera.

Verificam que:
1. Os arquivos de dados processados têm a forma e tipos corretos
2. O ChurnPreprocessor (stub) retorna arrays com shape e dtype esperados
3. O schema Pydantic rejeita payloads inválidos com 422
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pandera as pa
import pytest
from fastapi.testclient import TestClient
from pandera import Column, DataFrameSchema

from churn_telecom.schemas import CustomerFeatures


# ── Schema pandera para o dataset processado ──────────────────────────────────
PROCESSED_SCHEMA = DataFrameSchema(
    {
        "tenure_months": Column(float, pa.Check.ge(0)),
        "monthly_charges": Column(float, pa.Check.ge(0)),
        "total_charges": Column(float, pa.Check.ge(0)),
        "num_services": Column(float, pa.Check.ge(0)),
        "charges_per_month": Column(float, pa.Check.ge(0)),
        "is_month_to_month": Column(float, pa.Check.isin([0.0, 1.0])),
        "has_security_support": Column(float, pa.Check.isin([0.0, 1.0])),
        "is_fiber_optic": Column(float, pa.Check.isin([0.0, 1.0])),
    },
    strict=False,
)


class TestProcessorOutputSchema:
    """Verifica que o output do preprocessor tem shape e dtype corretos."""

    def test_mock_returns_float32(self, mock_preprocessor, valid_payload) -> None:
        X = mock_preprocessor.transform(valid_payload)
        assert X.dtype == np.float32

    def test_mock_returns_2d(self, mock_preprocessor, valid_payload) -> None:
        X = mock_preprocessor.transform(valid_payload)
        assert X.ndim == 2

    def test_mock_returns_single_row(self, mock_preprocessor, valid_payload) -> None:
        X = mock_preprocessor.transform(valid_payload)
        assert X.shape[0] == 1

    def test_mock_n_features_consistent(self, mock_preprocessor, valid_payload) -> None:
        X = mock_preprocessor.transform(valid_payload)
        assert X.shape[1] == mock_preprocessor.n_features_out


class TestPydanticSchemaValidation:
    """Verifica que o schema Pydantic aceita válidos e rejeita inválidos."""

    def test_valid_payload_accepted(self, valid_payload) -> None:
        customer = CustomerFeatures(**valid_payload)
        assert customer.tenure_months == valid_payload["tenure_months"]

    def test_invalid_contract_rejected(self, valid_payload) -> None:
        bad = {**valid_payload, "contract": "Invalido"}
        with pytest.raises(Exception):
            CustomerFeatures(**bad)

    def test_negative_tenure_rejected(self, valid_payload) -> None:
        bad = {**valid_payload, "tenure_months": -1}
        with pytest.raises(Exception):
            CustomerFeatures(**bad)

    def test_monthly_charges_above_limit_rejected(self, valid_payload) -> None:
        bad = {**valid_payload, "monthly_charges": 500.0}
        with pytest.raises(Exception):
            CustomerFeatures(**bad)

    def test_invalid_internet_service_rejected(self, valid_payload) -> None:
        bad = {**valid_payload, "internet_service": "5G"}
        with pytest.raises(Exception):
            CustomerFeatures(**bad)


class TestApiSchemaContract:
    """Verifica que a API retorna 422 para payloads inválidos."""

    def test_missing_required_field_returns_422(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        payload = {k: v for k, v in valid_payload.items() if k != "tenure_months"}
        response = test_client.post("/predict", json=payload)
        assert response.status_code == 422

    def test_wrong_type_returns_422(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        response = test_client.post(
            "/predict", json={**valid_payload, "tenure_months": "doze"}
        )
        assert response.status_code == 422

    def test_invalid_literal_returns_422(
        self, test_client: TestClient, valid_payload: dict
    ) -> None:
        response = test_client.post(
            "/predict", json={**valid_payload, "contract": "SemContrato"}
        )
        assert response.status_code == 422

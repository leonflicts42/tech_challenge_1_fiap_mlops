"""Smoke tests — verificam que o serviço sobe e responde.

Não dependem de artefatos em disco (usam os mocks do conftest).
São os testes mais rápidos e devem ser os primeiros a rodar no CI.
"""
from __future__ import annotations

from fastapi.testclient import TestClient


def test_app_starts(test_client: TestClient) -> None:
    """Verifica que o app FastAPI foi inicializado sem erros."""
    assert test_client is not None


def test_health_returns_200(test_client: TestClient) -> None:
    """GET /health deve retornar 200."""
    response = test_client.get("/health")
    assert response.status_code == 200


def test_health_schema(test_client: TestClient) -> None:
    """GET /health retorna os campos obrigatórios com tipos corretos."""
    data = test_client.get("/health").json()
    assert "status" in data
    assert "model_loaded" in data
    assert "preprocessor_loaded" in data
    assert "model_version" in data
    assert isinstance(data["model_loaded"], bool)
    assert isinstance(data["preprocessor_loaded"], bool)


def test_health_with_mocks_is_healthy(test_client: TestClient) -> None:
    """Com mocks injetados, /health deve reportar 'healthy'."""
    data = test_client.get("/health").json()
    assert data["status"] == "healthy"
    assert data["model_loaded"] is True
    assert data["preprocessor_loaded"] is True


def test_predict_endpoint_exists(test_client: TestClient, valid_payload: dict) -> None:
    """POST /predict deve retornar 200 com payload válido."""
    response = test_client.post("/predict", json=valid_payload)
    assert response.status_code == 200


def test_request_id_header_present(test_client: TestClient, valid_payload: dict) -> None:
    """Toda resposta deve conter o header X-Request-ID."""
    response = test_client.post("/predict", json=valid_payload)
    assert "x-request-id" in response.headers


def test_latency_header_present(test_client: TestClient, valid_payload: dict) -> None:
    """Toda resposta deve conter o header X-Latency-Ms."""
    response = test_client.post("/predict", json=valid_payload)
    assert "x-latency-ms" in response.headers
